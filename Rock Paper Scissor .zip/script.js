let userScore=0;
let compScore=0;
let card= document.querySelectorAll(".card");
let msg= document.querySelector("#msg");
let userScorep=document.querySelector("#user-score");
let compScorep=document.querySelector("#comp-score");
card.forEach(card =>{
  card.addEventListener("click",()=>{
    let userchoice= card.getAttribute("id");
  playgame(userchoice);
  });
});
const playgame=(userchoice)=>{
  console.log ("You have chosen", userchoice);
  const compChoice=genCompChoice();
  console.log("computer have chosen",compChoice);
if(userchoice===compChoice){
  drawGame();
}
else{
  let userWin=true;
  if(userchoice==="rock"){
    userWin=compChoice==="paper"?false:true;
  }
  else if (userchoice==="paper") {
    userWin=compChoice==="scissor"?false:true;
  }
  else {
    userWin=compChoice==="rock"?false:true;
  }
  showWin(userWin);
}
}
const genCompChoice=()=>{
  const options =["rock","paper","scissor"];
 const randInx= Math.floor(Math.random()*3);
return options[randInx];
}
const drawGame=()=>{
  console.log("Game draw! play again");
  msg.innerText="draw Move!";
  msg.style.backgroundColor="grey";
}
const showWin=(userWin)=>{
  if(userWin){
    userScore++;
    userScorep.innerText=userScore;
    console.log("You Win!");
    msg.innerText="You are Winning!";
    msg.style.backgroundColor="#c8a8e9";
  }
  else{
    compScore++;
    compScorep.innerText=compScore;
    console.log("You loose!");
    msg.innerText=("You are loosing!");
    msg.style.backgroundColor="pink";
  }
}
let restart=document.querySelector(".restart-btn")
restart.addEventListener('click',()=>{
  res(restart);
});
let res=(restart)=>{
  compScorep.innerText=0;
  userScorep.innerText=0;
  msg.innerText="Play Your Move";
  msg.style.backgroundColor="#c3c7f4";
}
let audio =()=>{
  Audio('/Rock Paper Scissor /mixkit-winning-a-coin-video-game-2069.wav');
audio.play();
}